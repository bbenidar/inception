import 'package:flutter/material.dart';
import 'splashScreen2.dart'; // Import the SplashScreen2 file
import './auth/player/login.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  static const String _title = 'Flutter Stateful Clicker Counter';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: TextTheme(
          bodyText1: TextStyle(color: Colors.white),
          bodyText2: TextStyle(color: Colors.white),
        ),
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool _isNavigating = false; // Flag to prevent multiple navigations

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF6FE640), // Background color
      body: GestureDetector(
        onPanUpdate: (details) {
          // Check if the swipe direction is primarily horizontal and leftward
          if (details.delta.dx < -5 && !_isNavigating) {
            // Adjust threshold for swipe detection
            // Set flag to true to prevent multiple navigations
            setState(() {
              _isNavigating = true;
            });
            // Navigate to SplashScreen2
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => Onboarding05Widget()),
            );
          }
        },
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.spaceBetween, // Space between children
          children: [
            Expanded(
              child: Center(
                child: Image.asset(
                  'assets/hhh.gif', // Path to your GIF file
                  width: 300, // Adjust the width as needed
                  height: 300, // Adjust the height as needed
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20.0), // Padding around the text
              child: Text(
                'Swipe to Start',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
